#FOR LOOP PROCESS WHERE EACH FILE THAT MUST BE LOADED IN IS A YEAR

library(tidyverse)

#Create an indentifier dataframe which contains the years which must be loaded in (i used preexisting dataframe as a shortcut)

stateinfo <- read.csv("allthedata.csv")

file_identifier_2 <- stateinfo %>% 
  filter(year >=2010) %>%
  select(year) %>% 
  distinct()

#Create an empty dataframe
panel_pop <- data_frame()


#The for loop:
##This works by repeating the entire process "for" every example of i (you get to define what i is)

#so, for every i, where i is the years that I selected in the first step...
for (i in file_identifier_2$year) {
  
#create an object called file_name_2 which is named the file path of the file of interest (note how it changes as i changes)  
  
  file_name_2 =  paste0("Populationdata/ACS_",i,".csv")

#create a new dataframe which reads in the file using the file_name_2 object we just created    
  popdata <- read.csv(file_name_2) %>%
    
#Do all of the normal data cleaning on it that you want to do
    select(NAME, S0101_C01_001E) %>% 
    filter(NAME != "Geographic Area Name") %>% 
    rename(Est_State_pop = S0101_C01_001E) %>% 
    rename(state = NAME) %>% 
    mutate(state = if_else(state == "Alabama", "AL", state))%>% 
    mutate(state = if_else(state == "Alaska", "AK", state)) %>% 
    mutate(state = if_else(state == "Arizona", "AZ", state)) %>%
    mutate(state = if_else(state == "Arkansas", "AR", state))%>% 
    mutate(state = if_else(state == "California", "CA", state)) %>% 
    mutate(state = if_else(state == "Colorado", "CO", state)) %>% 
    mutate(state = if_else(state == "Connecticut", "CT", state)) %>% 
    mutate(state = if_else(state == "Delaware", "DE", state)) %>% 
    mutate(state = if_else(state == "Florida", "FL", state)) %>% 
    mutate(state = if_else(state == "Georgia", "GA", state)) %>% 
    mutate(state = if_else(state == "Hawaii", "HI", state)) %>% 
    mutate(state = if_else(state == "Idaho", "ID", state)) %>% 
    mutate(state = if_else(state == "Illinois", "IL", state)) %>% 
    mutate(state = if_else(state == "Indiana", "IN", state)) %>% 
    mutate(state = if_else(state == "Iowa", "IA", state)) %>% 
    mutate(state = if_else(state == "Kansas", "KS", state)) %>% 
    mutate(state = if_else(state == "Kentucky", "KY", state)) %>% 
    mutate(state = if_else(state == "Louisiana", "LA", state)) %>%
    mutate(state = if_else(state == "Lousiana", "LA", state)) %>% 
    mutate(state = if_else(state == "Maine", "ME", state)) %>% 
    mutate(state = if_else(state == "Maryland", "MD", state)) %>% 
    mutate(state = if_else(state == "Massachusetts", "MA", state)) %>% 
    mutate(state = if_else(state == "Michigan", "MI", state)) %>% 
    mutate(state = if_else(state == "Minnesota", "MN", state)) %>% 
    mutate(state = if_else(state == "Mississippi", "MS", state)) %>% 
    mutate(state = if_else(state == "Missouri", "MO", state)) %>% 
    mutate(state = if_else(state == "Montana", "MT", state)) %>% 
    mutate(state = if_else(state == "Nebraska", "NE", state)) %>% 
    mutate(state = if_else(state == "Nevada", "NV", state)) %>%
    mutate(state = if_else(state == "New Hampshire", "NH", state)) %>% 
    mutate(state = if_else(state == "New Jersey", "NJ", state)) %>% 
    mutate(state = if_else(state == "New Mexico", "NM", state)) %>% 
    mutate(state = if_else(state == "New York", "NY", state)) %>% 
    mutate(state = if_else(state == "North Carolina", "NC", state)) %>% 
    mutate(state = if_else(state == "North Dakota", "ND", state)) %>% 
    mutate(state = if_else(state == "Ohio", "OH", state)) %>% 
    mutate(state = if_else(state == "Oklahoma", "OK", state)) %>% 
    mutate(state = if_else(state == "Oregon", "OR", state)) %>% 
    mutate(state = if_else(state == "Pennsylvania", "PA", state)) %>% 
    mutate(state = if_else(state == "Rhode Island", "RI", state)) %>% 
    mutate(state = if_else(state == "South Carolina", "SC", state)) %>% 
    mutate(state = if_else(state == "South Dakota", "SD", state)) %>% 
    mutate(state = if_else(state == "Tennessee", "TN", state)) %>% 
    mutate(state = if_else(state == "Texas", "TX", state)) %>% 
    mutate(state = if_else(state == "Utah", "UT", state)) %>% 
    mutate(state = if_else(state == "Vermont", "VT", state)) %>% 
    mutate(state = if_else(state == "Virginia", "VA", state)) %>% 
    mutate(state = if_else(state == "Washington", "WA", state)) %>% 
    mutate(state = if_else(state == "West Virginia", "WV", state)) %>% 
    mutate(state = if_else(state == "Wisconsin", "WI", state)) %>% 
    mutate(state = if_else(state == "Wyoming", "WY", state)) %>%

#make a column "year" which takes the value of i, which is the year from the dataframe in step 1        
    mutate(year = i)

#stack this new creation on the bottom of the empty dataframe we made in step 2
  
  panel_pop <- panel_pop %>% 
    rbind(popdata)

#print the year so that you know where it is in the process and can identify any files which do not work    
  print(i)
  
#stop the looping process, so that it will iterate on i until it runs out of i's.    
}

#Wham! now you have a panel dataset which includes state-year population data. 
